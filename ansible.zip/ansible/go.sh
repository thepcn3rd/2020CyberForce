#!/bin/bash

echo "If you are running this script for the first time run the following:"
echo "sudo apt install ansible sshpass"
echo "sudo systemctl enable ssh"
echo "sudo systemctl start ssh"

ansible-playbook -i inventory.yaml configure.yml


